//
//  Multiplication.h
//  Multiplication
//
//  Created by Vivek Lalan on 22/05/24.
//

#import <Foundation/Foundation.h>

//! Project version number for Multiplication.
FOUNDATION_EXPORT double MultiplicationVersionNumber;

//! Project version string for Multiplication.
FOUNDATION_EXPORT const unsigned char MultiplicationVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Multiplication/PublicHeader.h>


